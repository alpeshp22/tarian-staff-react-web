export const LOGO = require('../assets/images/logo.png')
export const LOGO_COLOR = require('../assets/images/logo-colored.png')