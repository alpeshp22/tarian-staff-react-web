const IMAGE = {
    LOGO: require('./logo.png').default,
    LOGIN_BG: require('./login_bg.png').default,
    SIDEBAR_BG: require('./sidebar_bg.png').default,
}

export default IMAGE;