<!-- 
MoveoApps Repo Details
----------------------------------------
Link: https://Hiralatha@bitbucket.org/voidapplications/tarian-staff-web-app.git
ID: hiral@moveoapps.com		
PASS: 1) MOVEOLogin#2020 (2)  BitNew!!Login#224	
App Pass	GUA5eaTdzWsbZcre9HFA

----------------------------------------
Web Creds:
UID: Prescriptions
UPASS: Password1
**VPN
----------------------------------------
-->
